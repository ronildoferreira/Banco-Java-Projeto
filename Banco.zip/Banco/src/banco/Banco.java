/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

/**
 *
 * @author ronil
 */
public class Banco{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Conta criada para testar o rendimeto de 500 na conta com 0,02% = 510
        
        ContaPoupanca ct0 = new ContaPoupanca(1010101,101,11,500);
        System.out.println("\n************ ContaPoupança 010 *****************\n");
        
        ct0.rendimento(0.02);
        ct0.extrato();
        System.out.println("\n**********************************************\n");
        
        /**Crie duas contas correntes e duas poupanças (pode definir os números das contas como quiser)
        Inicie as contas com saldos e limites diferentes de zero.*/
        
        ContaCorrente ct1 = new ContaCorrente(1111111,1010,1,3000);
        ContaCorrente ct2 = new ContaCorrente(2222222,1212,2,2500);
        ContaPoupanca ct3 = new ContaPoupanca(3333333,1313,3,1500);
        ContaPoupanca ct4 = new ContaPoupanca(4444444,1414,4,1000);
        
        
        //Realize dois saques em quaisquer contas e exiba o saldo a seguir.
        System.out.println("\n************ ContaCorrente 01 *****************\n");
        ct1.saque(1000);
        ct1.extrato();
        System.out.println("\n**********************************************\n");
        
        //Realize dois saques em quaisquer contas e exiba o saldo a seguir.
        System.out.println("\n************ ContaCorrente 02 *****************\n");
        ct2.saque(750);
        ct2.extrato();
        System.out.println("\n***********************************************\n");
        
        //Realize dois saques em quaisquer contas e exiba o saldo a seguir.
        System.out.println("\n************ ContaPoupança 03 *****************\n");
        ct3.saque(100);
        ct3.rendimento(0.02);
        ct3.extrato();
        System.out.println("\n**********************************************\n");
        
        //Realize dois saques em quaisquer contas e exiba o saldo a seguir.
        System.out.println("\n************ ContaPoupança 04 *****************\n");
        ct4.saque(50);
        ct4.rendimento(0.02);
        ct4.extrato();
        System.out.println("\n***********************************************\n");
        
        //Realize duas transferências e exiba os saldos das contas envolvidas.
        System.out.println("\n*************** Transferencia *****************\n");
        
        ct1.transferencia(300, ct2);
        ct1.extrato();
        System.out.println("\nValor transferido para:");
        ct2.extrato();
        System.out.println("\n***********************************************\n");
        
        /**Realize duas transferências e exiba os saldos das contas envolvidas.*/
        System.out.println("\n*************** Transferencia *****************\n");
        ct3.rendimento(0.02);
        ct3.transferencia(100, ct4);
        ct3.extrato();
        System.out.println("\nValor transferido para:");
        ct4.rendimento(0.02);
        ct4.extrato();
        System.out.println("\n***********************************************\n");
         
       /**Realize tentativas de um saque e uma transferência para uma conta corrente que não tenha saldo
       suficiente mesmo com o limite.*/
       System.out.println("\n********** Transferencia e saque ***************\n");
        ct2.saque(3000);
        ct2.extrato();
        ct1.transferencia(3000, ct2);
        ct1.extrato();
        System.out.println("\n***********************************************\n");
        
        /**Realize tentativas de um saque e uma transferência para uma conta poupança que não tenha saldo
        suficiente.*/
        System.out.println("\n*************** Transferencia *****************\n");
        
        ct3.saque(2500);
        ct3.extrato();
        ct3.transferencia(2000, ct4);
        ct4.extrato();
        System.out.println("\n***********************************************\n");
        
        //Teste do metodo deposito
        System.out.println("\n*************** Deposito *****************\n");
        ct1.deposito(100);
        ct1.extrato();
        System.out.println("\n***********************************************\n");
        
        System.out.println("\n*************** Deposito *****************\n");
        ct2.deposito(200);
        ct2.extrato();
        System.out.println("\n***********************************************\n");
        
     }
    
}
