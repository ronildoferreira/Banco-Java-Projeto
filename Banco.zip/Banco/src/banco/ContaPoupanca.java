/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

/**
 *
 * @author ronil
 */
public class ContaPoupanca extends Conta{
    
    private double perc;
    
    public ContaPoupanca(int numero, int agencia, int digito, double saldo){
        super(numero,agencia,digito,saldo);
    }
    
    public void rendimento(double perc){
    this.setSaldo(this.getSaldo() + this.getSaldo() * perc);
    }
    
    
    /**
     * @return the perc
     */
    public double getPerc() {
        return perc;
    }

    /**
     * @param perc the perc to set
     */
    public void setPerc(double perc) {
        this.perc = perc;
    }

 }
    

