/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

/**
 *
 * @author ronil
 */
public class ContaCorrente extends Conta{
   private double limite;
   
   public ContaCorrente(int numero, int agencia, int digito, double saldo){
        super(numero,agencia,digito,saldo);
        this.limite = saldo;
        
   }
   
 
 /**@Override  
 public void saque(double valor){}*/
 
 /**@Override  
 public void transferencia(double valor){}*/
 
 
 /**
     * @return the limite
     */
    public double getLimite() {
        return limite;
    }

    /**
     * @param limite the limite to set
     */
    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    public double saque() {
       return 0;
       
   
    }

    void setDepoito(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
