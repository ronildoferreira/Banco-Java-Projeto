/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

/**
 *
 * @author ronil
 */
public class Conta {
 
    private int agencia;
    private int numero;
    private int digito;
    private double saldo;
    
     public Conta(int numero, int agencia, int digito, double saldo) {
		this.numero = numero;
		this.agencia = agencia;
		this.digito = digito;
		this.saldo = saldo;
	}
    
    public void deposito(double val) {
           this.saldo += val; 
          // System.out.println("\nO Depósito foi realizado com sucesso!!!");
       }
       
    public void saque(double val) {
        if (val <= this.saldo) {
            this.saldo -= val;
            System.out.println("Saque realizado com sucesso!!!");     
                } else {
            System.out.println("A conta não possui essa quantia para saque!!!");
        }
    }
    
      public void transferencia(double val , Conta ct){
          if(val <= saldo){
              System.out.println("\nTransferencia realizada com Sucesso!!!\n");
                saldo -= val;
                ct.deposito(val);    
                    }else{
              System.out.println("\nTransferencia não Concluida!!!\n");
          }
	}
      
     public void extrato(){
        System.out.println("Agencia:"+getAgencia()+"\nNumero: "+getNumero()+"\nDigito:"+getDigito()+"\nSaldo:"+saldo);
     }
    /**
     * @return the agencia
     */
    public int getAgencia() {
        return agencia;
    }

    /**
     * @param agencia the agencia to set
     */
    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the digito
     */
    public int getDigito() {
        return digito;
    }

    /**
     * @param digito the digito to set
     */
    public void setDigito(int digito) {
        this.digito = digito;
    }


     public double getSaldo() {
        return saldo;
   
    }
    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
   
    }
     
}
